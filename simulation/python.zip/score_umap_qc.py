#!/usr/bin/env python3
"""
Quantify UMAP neighbor purity vs ground-truth labels (QC for simulation tuning).

Reads adata.h5ad + figures/umap_coords_*.csv (same layout as plot_umaps_scanpy).
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree

EMBED_FILES = (
    ("batch_free", "umap_coords_batch_free.csv"),
    ("observed", "umap_coords_observed.csv"),
)


def neighbor_purity(coords: np.ndarray, labels: np.ndarray, k: int) -> float:
    n = coords.shape[0]
    if n < 3:
        return float("nan")
    kk = min(k, n - 1)
    tree = cKDTree(coords)
    dist, idx = tree.query(coords, k=kk + 1, workers=-1)
    idx = idx[:, 1:]
    hits = 0
    total = 0
    for i in range(n):
        li = labels[i]
        neigh = labels[idx[i]]
        hits += int(np.sum(neigh == li))
        total += neigh.size
    return float(hits / max(total, 1))


def load_coords(fig_dir: Path, fname: str, cell_ids: pd.Index) -> np.ndarray | None:
    path = fig_dir / fname
    if not path.exists():
        return None
    df = pd.read_csv(path).set_index("cell_id").reindex(cell_ids)
    if df.isna().any().any():
        raise ValueError(f"{path}: missing cells after align")
    return np.asarray(df[["UMAP1", "UMAP2"]], dtype=np.float64)


def score_bundle(out_dir: Path, k: int) -> dict[str, float | str]:
    out_dir = out_dir.resolve()
    h5ad = out_dir / "adata.h5ad"
    fig_dir = out_dir / "figures"
    if not h5ad.exists():
        raise FileNotFoundError(h5ad)
    adata = ad.read_h5ad(h5ad)
    if "type_condition" not in adata.obs.columns or "type_condition_batch" not in adata.obs.columns:
        raise ValueError("adata.obs needs type_condition and type_condition_batch (re-run convert_to_h5ad)")
    out: dict[str, float | str] = {"out_dir": str(out_dir)}
    lab_tc = np.asarray(adata.obs["type_condition"].astype(str))
    lab_tcb = np.asarray(adata.obs["type_condition_batch"].astype(str))
    lab_batch = np.asarray(adata.obs["batch"].astype(str))
    for logical, fname in EMBED_FILES:
        xy = load_coords(fig_dir, fname, adata.obs_names)
        if xy is None:
            continue
        out[f"{logical}_purity_type_condition"] = neighbor_purity(xy, lab_tc, k)
        out[f"{logical}_purity_type_condition_batch"] = neighbor_purity(xy, lab_tcb, k)
        out[f"{logical}_purity_batch_only"] = neighbor_purity(xy, lab_batch, k)
    return out


def passes(row: dict[str, float], min_obs_tcb: float, min_bf_tc: float, max_bf_batch: float) -> bool:
    obs_tcb = row.get("observed_purity_type_condition_batch")
    bf_tc = row.get("batch_free_purity_type_condition")
    bf_b = row.get("batch_free_purity_batch_only")
    if obs_tcb is None or bf_tc is None or bf_b is None:
        return False
    if np.isnan(obs_tcb) or np.isnan(bf_tc) or np.isnan(bf_b):
        return False
    return bool(obs_tcb >= min_obs_tcb and bf_tc >= min_bf_tc and bf_b <= max_bf_batch)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", required=True, help="Single bundle (replicate folder)")
    parser.add_argument("--knn", type=int, default=30)
    parser.add_argument(
        "--min-obs-tcb",
        type=float,
        default=0.62,
        help="Minimum neighbor purity for type|condition|batch on observed UMAP",
    )
    parser.add_argument(
        "--min-bf-tc",
        type=float,
        default=0.58,
        help="Minimum neighbor purity for type|condition on batch-free UMAP",
    )
    parser.add_argument(
        "--max-bf-batch",
        type=float,
        default=0.42,
        help="Batch-only purity on batch-free should stay low (no batch islands)",
    )
    parser.add_argument(
        "--append-md",
        default="",
        help="If set, append a markdown table row to this file",
    )
    args = parser.parse_args()
    row = score_bundle(Path(args.out_dir), args.knn)
    ok = passes(row, args.min_obs_tcb, args.min_bf_tc, args.max_bf_batch)
    row["passes_criteria"] = float(ok)
    for k, v in row.items():
        if k != "out_dir" and isinstance(v, float):
            print(f"{k}\t{v:.4f}")
        elif k != "out_dir":
            print(f"{k}\t{v}")
    print(f"passes_criteria\t{int(ok)}")
    if args.append_md:
        path = Path(args.append_md)
        path.parent.mkdir(parents=True, exist_ok=True)
        line = (
            f"| {Path(args.out_dir).name} | {row.get('observed_purity_type_condition_batch', float('nan')):.3f} | "
            f"{row.get('batch_free_purity_type_condition', float('nan')):.3f} | "
            f"{row.get('batch_free_purity_batch_only', float('nan')):.3f} | {int(ok)} |\n"
        )
        if not path.exists():
            path.write_text(
                "| bundle | obs purity (type|cond|batch) | bf purity (type|cond) | "
                "bf purity (batch only) | pass |\n|---|---:|---:|---:|---|\n"
            )
        with path.open("a") as handle:
            handle.write(line)


if __name__ == "__main__":
    main()
