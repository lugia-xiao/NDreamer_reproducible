#!/usr/bin/env python3
"""
Plot UMAP coordinates produced in R using scanpy (larger points, clearer legends).

Expects:
  - adata.h5ad in the bundle directory
  - figures/umap_coords_{latent,batch_free,observed}.csv (cell_id, UMAP1, UMAP2)
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import anndata as ad
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    import scanpy as sc
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "scanpy is required for UMAP plots. Install with: pip install scanpy matplotlib"
    ) from exc

# R writes CSVs; obsm keys must match scanpy (basis "umap_latent" -> obsm["X_umap_latent"]).
EMBED_META = (
    ("latent", "umap_coords_latent.csv", "X_umap_latent", "umap_latent"),
    ("batch_free", "umap_coords_batch_free.csv", "X_umap_batch_free", "umap_batch_free"),
    ("observed", "umap_coords_observed.csv", "X_umap_observed", "umap_observed"),
)

COLOR_FIELDS = (
    "cell_type",
    "batch",
    "condition",
    "type_condition",
    "type_condition_batch",
)


def read_manifest(path: Path) -> list[dict]:
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def attach_umaps(adata: ad.AnnData, fig_dir: Path) -> list[tuple[str, str]]:
    """Load CSV coords into adata.obsm; return list of (logical_name, scanpy_basis)."""
    attached: list[tuple[str, str]] = []
    for logical, fname, obsm_key, basis in EMBED_META:
        path = fig_dir / fname
        if not path.exists():
            continue
        coord = pd.read_csv(path)
        if "cell_id" not in coord.columns:
            raise ValueError(f"{path} must contain cell_id")
        coord = coord.set_index("cell_id").reindex(adata.obs_names)
        if coord.isna().any().any():
            missing = int(coord.isna().any(axis=1).sum())
            raise ValueError(f"{path}: {missing} cells missing after align to adata.obs_names")
        mat = np.asarray(coord[["UMAP1", "UMAP2"]], dtype=np.float32)
        adata.obsm[obsm_key] = mat
        attached.append((logical, basis))
    return attached


def plot_bundle(out_dir: Path, point_size: float = 120.0) -> None:
    out_dir = out_dir.resolve()
    if not out_dir.is_dir():
        print(f"Skip (not a directory): {out_dir}")
        return
    h5ad = out_dir / "adata.h5ad"
    if not h5ad.exists():
        print(f"Skip (no h5ad): {out_dir}")
        return
    fig_dir = out_dir / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)
    for stale in fig_dir.glob("scanpy_*.png"):
        stale.unlink()

    adata = ad.read_h5ad(h5ad)
    bases = attach_umaps(adata, fig_dir)
    if not bases:
        print(f"No UMAP coordinate CSVs under {fig_dir}; skip plotting.")
        return

    sc.set_figure_params(dpi=120, frameon=False, figsize=(6, 5), vector_friendly=True)
    for logical, basis in bases:
        for color in COLOR_FIELDS:
            if color not in adata.obs.columns:
                continue
            fig, ax = plt.subplots(figsize=(6.5, 5.5))
            sc.pl.embedding(
                adata,
                basis=basis,
                color=color,
                ax=ax,
                show=False,
                size=point_size,
                title=f"{logical.replace('_', ' ')} | {color}",
                legend_fontsize=10,
            )
            out_png = fig_dir / f"scanpy_{logical}_{color}.png"
            fig.savefig(out_png, dpi=200, bbox_inches="tight")
            plt.close(fig)
        print(f"  wrote scanpy UMAPs ({logical}) -> {fig_dir}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Scanpy UMAP plots from R-exported coordinates.")
    parser.add_argument(
        "--manifest",
        default="",
        help="CSV manifest with out_dir column (omit if using --out-dir)",
    )
    parser.add_argument(
        "--point-size",
        type=float,
        default=120.0,
        help="Scatter point size passed to scanpy (default: 120)",
    )
    parser.add_argument(
        "--out-dir",
        default="",
        help="If set, plot only this bundle directory (ignores manifest).",
    )
    args = parser.parse_args()

    if args.out_dir:
        plot_bundle(Path(args.out_dir).resolve(), point_size=args.point_size)
        return

    if not args.manifest:
        raise SystemExit("Provide --manifest or --out-dir")

    manifest = Path(args.manifest)
    rows = read_manifest(manifest)
    if not rows:
        print("Manifest empty; nothing to plot.")
        return
    for row in rows:
        out_dir = Path(row["out_dir"]).resolve()
        if not out_dir.is_dir():
            print(f"Skip missing path: {out_dir}")
            continue
        print(f"Scanpy UMAP plots: {out_dir}")
        plot_bundle(out_dir, point_size=args.point_size)


if __name__ == "__main__":
    main()
