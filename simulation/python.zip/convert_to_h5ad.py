#!/usr/bin/env python3
"""
Convert MTX + CSV bundles produced by R into AnnData objects.
"""

from __future__ import annotations

import argparse
import csv
import gzip
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import yaml
from scipy.io import mmread


def read_manifest(path: Path) -> list[dict]:
    rows: list[dict] = []
    with path.open(newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            rows.append(row)
    return rows


def load_bundle(out_dir: Path) -> ad.AnnData:
    mtx_path = out_dir / "counts.mtx.gz"
    if not mtx_path.exists():
        mtx_path = out_dir / "counts.mtx"
    if not mtx_path.exists():
        raise FileNotFoundError(f"Missing counts matrix in {out_dir}")

    obs = pd.read_csv(out_dir / "obs.csv")
    var = pd.read_csv(out_dir / "var.csv")
    if "cell_id" not in obs.columns:
        raise ValueError("obs.csv must contain cell_id")
    if "gene_id" not in var.columns:
        raise ValueError("var.csv must contain gene_id")

    if str(mtx_path).endswith(".gz"):
        with gzip.open(mtx_path, "rb") as handle:
            mat = mmread(handle).tocsr()
    else:
        mat = mmread(mtx_path).tocsr()
    if mat.shape[0] != var.shape[0] or mat.shape[1] != obs.shape[0]:
        raise ValueError(
            f"Dimension mismatch: mat {mat.shape}, obs {obs.shape}, var {var.shape}"
        )
    x = mat.T.tocsr()
    adata = ad.AnnData(X=x, dtype=np.float32)
    adata.obs = obs.set_index("cell_id")
    adata.var = var.set_index("gene_id")
    o = adata.obs
    if all(c in o.columns for c in ("cell_type", "condition", "batch")):
        adata.obs["type_condition"] = (
            o["cell_type"].astype(str) + "|" + o["condition"].astype(str)
        )
        adata.obs["type_condition_batch"] = (
            adata.obs["type_condition"].astype(str) + "|" + o["batch"].astype(str)
        )

    summary_path = out_dir / "simulation_summary.yaml"
    if summary_path.exists():
        with summary_path.open() as handle:
            adata.uns["simulation_summary"] = yaml.safe_load(handle)

    truth_path = out_dir / "truth.rds"
    if truth_path.exists():
        adata.uns["truth_rds"] = str(truth_path)

    return adata


def convert_one(out_dir: Path, overwrite: bool = False) -> bool:
    """Return True if adata.h5ad exists after call (written or skipped as existing)."""
    if not out_dir.is_dir():
        print(f"Skip (missing directory): {out_dir}")
        return False
    h5ad_path = out_dir / "adata.h5ad"
    if h5ad_path.exists() and not overwrite:
        print(f"Skipping existing {h5ad_path}")
        return True
    try:
        adata = load_bundle(out_dir)
    except (FileNotFoundError, ValueError, OSError) as exc:
        print(f"Skip conversion {out_dir}: {exc}")
        return False
    print(f"Converting -> {h5ad_path}")
    adata.write_h5ad(h5ad_path, compression="gzip")
    return True


def convert_manifest(manifest: Path, overwrite: bool = False) -> None:
    entries = read_manifest(manifest)
    if not entries:
        print(f"No rows found in manifest {manifest}; skipping conversion.")
        return
    for row in entries:
        out_dir = Path(row["out_dir"]).resolve()
        if not out_dir.is_dir():
            print(f"Skip missing directory: {out_dir}")
            continue
        dataset = row.get("dataset", "")
        rep = row.get("replicate", "")
        scenario = row.get("scenario", "") or "NA"
        print(f"Manifest entry {dataset} rep={rep} scenario={scenario} -> {out_dir}")
        convert_one(out_dir, overwrite=overwrite)


def main() -> None:
    parser = argparse.ArgumentParser(description="Convert simulation bundles to h5ad.")
    parser.add_argument(
        "--manifest",
        default="",
        help="CSV manifest with columns dataset,replicate,scenario,out_dir",
    )
    parser.add_argument(
        "--out-dir",
        default="",
        help="Convert only this bundle directory (ignores --manifest when set).",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing adata.h5ad files",
    )
    args = parser.parse_args()
    if args.out_dir:
        convert_one(Path(args.out_dir).resolve(), overwrite=args.overwrite)
        return
    if not args.manifest:
        raise SystemExit("Provide --manifest or --out-dir")
    convert_manifest(Path(args.manifest), overwrite=args.overwrite)


if __name__ == "__main__":
    main()
