# Shared helpers for paths, logging, seeds, and matrix orientation.
# Convention: SymSim outputs true counts as genes x cells; downstream
# cell-level objects use cells x genes unless noted.

`%||%` <- function(x, y) if (is.null(x) || length(x) == 0) y else x

script_dir <- function() {
  cmd_args <- commandArgs(trailingOnly = FALSE)
  file_arg <- "--file="
  i <- grep(file_arg, cmd_args)
  if (length(i)) {
    return(dirname(normalizePath(sub(file_arg, "", cmd_args[i]))))
  }
  # RStudio / interactive
  if (exists("ofile", inherits = TRUE)) {
    return(dirname(normalizePath(ofile)))
  }
  normalizePath(".")
}

project_root <- function() {
  env <- Sys.getenv("SIM_PROJECT_ROOT", unset = NA_character_)
  if (!is.na(env) && nzchar(env)) {
    return(normalizePath(env))
  }
  # Default: parent folder of generate_simulation_dataset/ when scripts live in R/
  sd <- script_dir()
  gen_dir <- normalizePath(file.path(sd, ".."))
  normalizePath(file.path(gen_dir, ".."))
}

code_dir <- function() {
  env <- Sys.getenv("SIM_CODE_DIR", unset = NA_character_)
  if (!is.na(env) && nzchar(env)) {
    return(normalizePath(env))
  }
  script_dir()
}

log_info <- function(...) {
  ts <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  message(paste0("[", ts, "] ", ...))
}

log_stop <- function(...) {
  stop(paste0(...), call. = FALSE)
}

ensure_dir <- function(path) {
  if (!dir.exists(path)) {
    dir.create(path, recursive = TRUE, showWarnings = FALSE)
  }
  invisible(path)
}

# Remove replicate_XX folders with XX > n_rep (e.g. after lowering n_replicates in YAML).
prune_stale_replicates <- function(data_root, n_rep) {
  if (!dir.exists(data_root)) {
    return(invisible())
  }
  dirs <- list.dirs(data_root, recursive = FALSE, full.names = TRUE)
  for (d in dirs) {
    bn <- basename(d)
    if (!grepl("^replicate_", bn)) {
      next
    }
    num <- suppressWarnings(as.integer(sub("^replicate_", "", bn)))
    if (!is.na(num) && num > n_rep) {
      unlink(d, recursive = TRUE)
      log_info("Removed stale replicate directory: ", d)
    }
  }
  invisible()
}

read_yaml_safe <- function(path) {
  if (!file.exists(path)) {
    log_stop("Config not found: ", path)
  }
  yaml::yaml.load_file(path)
}

write_yaml_safe <- function(obj, path) {
  ensure_dir(dirname(path))
  yaml::write_yaml(obj, path)
}

# Greedy least-loaded assignment for a shuffled pool of length n_batches * cells_per_batch.
# Returns a permutation of batch ids in 1..n_batches (length equals pool size).
assign_batches_least_loaded_perm <- function(n_batches, cells_per_batch, seed) {
  set.seed(seed)
  pool <- n_batches * cells_per_batch
  ord <- sample.int(pool)
  lbl <- rep(NA_integer_, pool)
  load <- rep(0L, n_batches)
  for (j in ord) {
    pick <- which.min(load)
    lbl[j] <- pick
    load[pick] <- load[pick] + 1L
  }
  lbl
}

# Split each cell type ~50/50 between conditions, then batch within condition.
# Fixed design: 2 conditions × 3 batches each = 6 global batches (control: 1–3, perturbed: 4–6).
assign_condition_and_global_batch <- function(population, n_batches = 6L,
                                                cells_per_batch, seed) {
  set.seed(seed)
  n <- length(population)
  stopifnot(n_batches == 6L)
  stopifnot(n == n_batches * cells_per_batch)
  batches_per_cond <- 3L
  cond <- rep(NA_character_, n)
  batch <- rep(NA_integer_, n)
  pops <- sort(unique(as.character(population)))
  ctrl_pool <- integer(0)
  pert_pool <- integer(0)
  for (p in pops) {
    idx <- which(as.character(population) == p)
    idx <- sample(idx)
    split <- floor(length(idx) / 2)
    if (split > 0L) {
      ctrl_pool <- c(ctrl_pool, idx[seq_len(split)])
    }
    if (split < length(idx)) {
      pert_pool <- c(pert_pool, idx[seq.int(split + 1L, length(idx))])
    }
  }
  while (length(ctrl_pool) > n / 2L) {
    mv <- sample(ctrl_pool, 1L)
    ctrl_pool <- ctrl_pool[ctrl_pool != mv]
    pert_pool <- c(pert_pool, mv)
  }
  while (length(ctrl_pool) < n / 2L) {
    mv <- sample(pert_pool, 1L)
    pert_pool <- pert_pool[pert_pool != mv]
    ctrl_pool <- c(ctrl_pool, mv)
  }
  if (length(ctrl_pool) != n / 2L || length(pert_pool) != n / 2L) {
    log_stop("Condition split did not yield equal halves; check population vector.")
  }
  ctrl_perm <- assign_batches_least_loaded_perm(
    n_batches = batches_per_cond,
    cells_per_batch = cells_per_batch,
    seed = seed + 11L
  )
  pert_perm <- assign_batches_least_loaded_perm(
    n_batches = batches_per_cond,
    cells_per_batch = cells_per_batch,
    seed = seed + 23L
  )
  ctrl_pool_shuffled <- sample(ctrl_pool)
  pert_pool_shuffled <- sample(pert_pool)
  cond[ctrl_pool_shuffled] <- "control"
  cond[pert_pool_shuffled] <- "perturbed"
  batch[ctrl_pool_shuffled] <- ctrl_perm
  batch[pert_pool_shuffled] <- pert_perm + 3L
  list(condition = cond, batch = batch)
}

minmax_cols <- function(U) {
  H <- U
  for (k in seq_len(ncol(U))) {
    col <- U[, k]
    lo <- min(col)
    hi <- max(col)
    if (!is.finite(lo) || !is.finite(hi) || hi == lo) {
      H[, k] <- 0.5
    } else {
      H[, k] <- (col - lo) / (hi - lo)
    }
  }
  H
}

nb_matrix <- function(mu, theta_vec, seed) {
  set.seed(seed)
  n_cells <- nrow(mu)
  n_genes <- ncol(mu)
  if (length(theta_vec) != n_genes) {
    log_stop("theta_vec length must match n_genes")
  }
  Y <- matrix(0, nrow = n_cells, ncol = n_genes)
  for (g in seq_len(n_genes)) {
    Y[, g] <- stats::rnbinom(n_cells, size = theta_vec[g], mu = pmax(mu[, g], 1e-12))
  }
  Y
}

# Per-gene one-way ANOVA F (between discrete groups); returns length ncol(expr_cxg).
per_gene_group_f_scores <- function(expr_cxg, group_vec) {
  grp <- as.integer(as.factor(group_vec))
  n <- nrow(expr_cxg)
  P <- max(grp)
  G <- ncol(expr_cxg)
  if (P < 2L || n < P + 1L) {
    return(rep(0, G))
  }
  n_p <- tabulate(grp, nbins = P)
  grand <- colMeans(expr_cxg)
  cm <- matrix(NA_real_, nrow = P, ncol = G)
  for (p in seq_len(P)) {
    rows <- which(grp == p)
    if (length(rows) > 0L) {
      cm[p, ] <- colMeans(expr_cxg[rows, , drop = FALSE])
    } else {
      cm[p, ] <- grand
    }
  }
  ss_between <- rep(0, G)
  for (p in seq_len(P)) {
    if (n_p[p] < 1L) {
      next
    }
    ss_between <- ss_between + n_p[p] * (cm[p, ] - grand)^2
  }
  pred <- cm[grp, , drop = FALSE]
  resid <- expr_cxg - pred
  ss_within <- colSums(resid^2)
  df1 <- max(P - 1L, 1L)
  df2 <- max(n - P, 1L)
  (ss_between / df1) / pmax(ss_within / df2, 1e-12)
}

# Genes with largest between-group / within-group F for a discrete cell grouping.
top_genes_group_f <- function(expr_cxg, group_vec, n_genes, seed) {
  set.seed(seed)
  G <- ncol(expr_cxg)
  if (n_genes < 1L) {
    return(integer(0))
  }
  Fg <- per_gene_group_f_scores(expr_cxg, group_vec)
  if (max(Fg) <= 0) {
    return(seq_len(min(G, n_genes)))
  }
  ord <- order(-Fg)
  ord[seq_len(min(n_genes, length(ord)))]
}

# Genes where batch separates cells *within control* and *within perturbed* (same condition).
top_genes_batch_within_condition_f <- function(expr_cxg, batch_index, condition, n_genes, seed) {
  set.seed(seed)
  G <- ncol(expr_cxg)
  if (n_genes < 1L) {
    return(integer(0))
  }
  cond <- as.character(condition)
  bi <- as.integer(batch_index)
  ctrl <- cond == "control"
  pert <- cond == "perturbed"
  Fc <- if (sum(ctrl) >= 6L) {
    per_gene_group_f_scores(expr_cxg[ctrl, , drop = FALSE], bi[ctrl])
  } else {
    rep(0, G)
  }
  Fp <- if (sum(pert) >= 6L) {
    per_gene_group_f_scores(expr_cxg[pert, , drop = FALSE], bi[pert])
  } else {
    rep(0, G)
  }
  # Average F rewards batch signal in both conditions (batches 1–3 vs 4–6 are separate pools).
  score <- 0.5 * (Fc + Fp)
  if (max(score) <= 0) {
    return(seq_len(min(G, n_genes)))
  }
  ord <- order(-score)
  ord[seq_len(min(n_genes, length(ord)))]
}

# Genes with largest between-cell-type variance (one-way layout) for UMAP PCA input.
top_genes_celltype_f <- function(expr_cxg, population, n_genes, seed) {
  top_genes_group_f(expr_cxg, as.integer(population), n_genes, seed)
}

# Top variance genes for PCA/UMAP visualization (cell types separate more clearly).
select_hvg_submatrix <- function(expr_cxg, n_hvg, seed) {
  if (n_hvg >= ncol(expr_cxg)) {
    return(expr_cxg)
  }
  set.seed(seed)
  v <- apply(expr_cxg, 2L, stats::var)
  ord <- order(-v)
  idx <- ord[seq_len(n_hvg)]
  expr_cxg[, idx, drop = FALSE]
}

# Matrix for UMAP PCA: F on cell type, joint type×condition, joint type×condition×batch,
# HVGs, or union (see YAML umap_gene_select*).
build_umap_expr_input <- function(expr_cxg, population, n_genes, seed, method = "f_stat",
                                  condition = NULL, batch_index = NULL) {
  method <- tolower(as.character(method[[1]]))
  n <- nrow(expr_cxg)
  if (method %in% c("joint_tc", "type_condition")) {
    if (is.null(condition) || length(condition) != n) {
      idx <- top_genes_celltype_f(expr_cxg, population, n_genes, seed)
      return(expr_cxg[, idx, drop = FALSE])
    }
    grp <- paste(as.integer(population), condition, sep = "\001")
    idx <- top_genes_group_f(expr_cxg, grp, n_genes, seed)
    return(expr_cxg[, idx, drop = FALSE])
  }
  if (method %in% c(
    "batch_within_condition", "within_condition_batch",
    "bwc", "same_condition_batch"
  )) {
    if (is.null(condition) || is.null(batch_index) ||
        length(condition) != n || length(batch_index) != n) {
      idx <- top_genes_celltype_f(expr_cxg, population, n_genes, seed)
      return(expr_cxg[, idx, drop = FALSE])
    }
    idx <- top_genes_batch_within_condition_f(expr_cxg, batch_index, condition, n_genes, seed)
    return(expr_cxg[, idx, drop = FALSE])
  }
  if (method %in% c("joint_tcb", "type_condition_batch", "observed_joint")) {
    if (is.null(condition) || length(condition) != n) {
      idx <- top_genes_celltype_f(expr_cxg, population, n_genes, seed)
      return(expr_cxg[, idx, drop = FALSE])
    }
    if (is.null(batch_index) || length(batch_index) != n) {
      grp <- paste(as.integer(population), condition, sep = "\001")
      idx <- top_genes_group_f(expr_cxg, grp, n_genes, seed)
      return(expr_cxg[, idx, drop = FALSE])
    }
    grp <- paste(as.integer(population), condition, as.integer(batch_index), sep = "\001")
    idx <- top_genes_group_f(expr_cxg, grp, n_genes, seed)
    return(expr_cxg[, idx, drop = FALSE])
  }
  if (method %in% c("f_stat", "f", "celltype", "cell_type")) {
    idx <- top_genes_celltype_f(expr_cxg, population, n_genes, seed)
    return(expr_cxg[, idx, drop = FALSE])
  }
  if (method %in% c("hvg", "var", "variance")) {
    return(select_hvg_submatrix(expr_cxg, n_genes, seed))
  }
  if (method %in% c("union", "both")) {
    n1 <- max(1L, ceiling(n_genes / 2L))
    n2 <- max(1L, n_genes - n1)
    i1 <- top_genes_celltype_f(expr_cxg, population, n1, seed)
    set.seed(seed + 7L)
    ord <- order(-apply(expr_cxg, 2L, stats::var))
    i2 <- ord[seq_len(min(n2, length(ord)))]
    idx <- unique(c(i1, i2))
    if (length(idx) > n_genes) {
      idx <- idx[seq_len(n_genes)]
    }
    return(expr_cxg[, idx, drop = FALSE])
  }
  idx <- top_genes_celltype_f(expr_cxg, population, n_genes, seed)
  expr_cxg[, idx, drop = FALSE]
}

# Dataset 2: one third of up genes and one third of down genes per tier (weak/medium/strong shifts).
assign_gene_effect_tiers <- function(gene_df, tier_shifts, seed) {
  set.seed(seed)
  out <- gene_df
  out$effect_tier <- NA_character_
  out$effect_shift <- 0
  canonical <- c("weak", "medium", "strong")
  tier_names <- canonical[vapply(canonical, function(nm) nm %in% names(tier_shifts), logical(1))]
  if (length(tier_names) != 3L) {
    log_stop("effect_tiers must define weak, medium, and strong shifts.")
  }
  ts <- tier_shifts[tier_names]
  up <- which(out$direction == "up")
  down <- which(out$direction == "down")
  if (length(up) %% 3L != 0L || length(down) %% 3L != 0L) {
    log_stop("Counts of up/down genes must be divisible by 3 for 1/3 per tier.")
  }
  n_t <- length(up) %/% 3L
  up_sh <- sample(up)
  down_sh <- sample(down)
  for (ti in 1:3) {
    tier <- tier_names[ti]
    sh <- unname(ts[[tier]])
    if (!is.finite(sh) || sh <= 0) {
      log_stop("Invalid tier shift for ", tier)
    }
    gu <- up_sh[(ti - 1L) * n_t + seq_len(n_t)]
    gd <- down_sh[(ti - 1L) * n_t + seq_len(n_t)]
    out$effect_tier[gu] <- tier
    out$effect_tier[gd] <- tier
    out$effect_shift[gu] <- sh
    out$effect_shift[gd] <- -sh
  }
  out
}

build_tau_matrix <- function(gene_df, H, n_cells, het_min = 0.5, het_max = 1.0) {
  n_genes <- nrow(gene_df)
  tau <- matrix(0, nrow = n_cells, ncol = n_genes)
  aff_idx <- which(gene_df$affected == "affected")
  for (g in aff_idx) {
    delta <- gene_df$effect_size[g]
    pc <- gene_df$assigned_pc[g]
    typ <- gene_df$het_type[g]
    if (is.na(pc)) {
      next
    }
    if (typ == "homogeneous") {
      tau[, g] <- delta
    } else if (typ == "heterogeneous") {
      tau[, g] <- delta * (het_min + (het_max - het_min) * H[, pc])
    }
  }
  tau
}

gene_partition_table <- function(ngenes, seed, n_pcs = 50L, effect_magnitude = 0.8) {
  set.seed(seed)
  genes <- sprintf("gene_%05d", seq_len(ngenes))
  n_aff <- round(0.6 * ngenes)
  aff_idx <- sample(seq_len(ngenes), n_aff)
  homo <- sample(aff_idx, round(length(aff_idx) / 2))
  het <- setdiff(aff_idx, homo)
  homo_up <- sample(homo, round(length(homo) / 2))
  homo_down <- setdiff(homo, homo_up)
  het_up <- sample(het, round(length(het) / 2))
  het_down <- setdiff(het, het_up)
  het_type <- rep("unaffected", ngenes)
  het_type[homo] <- "homogeneous"
  het_type[het] <- "heterogeneous"
  direction <- rep("none", ngenes)
  direction[homo_up] <- "up"
  direction[homo_down] <- "down"
  direction[het_up] <- "up"
  direction[het_down] <- "down"
  affected <- rep("unaffected", ngenes)
  affected[aff_idx] <- "affected"
  eff <- rep(0, ngenes)
  eff[c(homo_up, het_up)] <- effect_magnitude
  eff[c(homo_down, het_down)] <- -effect_magnitude
  pcs <- rep(NA_integer_, ngenes)
  if (length(aff_idx) > 0L) {
    if (length(aff_idx) %% n_pcs == 0L) {
      pcs[aff_idx] <- rep(seq_len(n_pcs), each = length(aff_idx) / n_pcs)
    } else {
      pcs[aff_idx] <- sample(rep(seq_len(n_pcs), length.out = length(aff_idx)))
    }
  }
  data.frame(
    gene_id = genes,
    affected = affected,
    het_type = het_type,
    direction = direction,
    effect_size = eff,
    assigned_pc = pcs,
    stringsAsFactors = FALSE
  )
}
