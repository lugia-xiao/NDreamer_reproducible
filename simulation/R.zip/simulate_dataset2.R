#!/usr/bin/env Rscript

parse_args <- function(args) {
  out <- list(config = NA_character_, help = FALSE)
  if ("--help" %in% args) {
    out$help <- TRUE
  }
  if ("--config" %in% args) {
    idx <- which(args == "--config")[[1]]
    out$config <- args[[idx + 1]]
  }
  out
}

main <- function() {
  args <- parse_args(commandArgs(trailingOnly = TRUE))
  if (args$help || is.na(args$config)) {
    message("Usage: Rscript simulate_dataset2.R --config path/to/sim_dataset2.yaml")
    quit(save = "no", status = 0)
  }

  cmd <- commandArgs(trailingOnly = FALSE)
  file_arg <- grep("^--file=", cmd, value = TRUE)
  code_dir <- if (length(file_arg)) {
    dirname(normalizePath(sub("^--file=", "", file_arg[[1]])))
  } else {
    normalizePath(".")
  }

  source(file.path(code_dir, "utils.R"))
  source(file.path(code_dir, "symsim_wrappers.R"))
  source(file.path(code_dir, "save_outputs.R"))
  source(file.path(code_dir, "generate_truth_tables.R"))
  source(file.path(code_dir, "plot_umaps.R"))

  cfg_path <- normalizePath(args$config, mustWork = TRUE)
  cfg <- read_yaml_safe(cfg_path)
  root <- project_root()
  data_root <- file.path(root, "data", "dataset2")
  ensure_dir(data_root)
  manifest_path <- normalizePath(
    file.path(root, "generate_simulation_dataset", "logs", "h5ad_manifest.csv"),
    mustWork = FALSE
  )
  ensure_dir(dirname(manifest_path))

  tier_shifts <- cfg$effect_tiers
  if (is.null(tier_shifts) || length(tier_shifts) != 3L) {
    log_stop("config must define effect_tiers with exactly three named shifts (weak, medium, strong).")
  }

  ngenes <- cfg$ngenes
  n_cells <- cfg$ncells_total
  cells_per_batch <- cfg$cells_per_batch
  n_batches <- cfg$n_batches
  if (n_cells != n_batches * cells_per_batch) {
    log_stop("ncells_total must equal n_batches * cells_per_batch")
  }
  n_rep <- cfg$n_replicates
  prune_stale_replicates(data_root, n_rep)

  for (rep in seq_len(n_rep)) {
    rep_seed <- cfg$master_seed + rep * 991L
    rep_dir <- file.path(data_root, sprintf("replicate_%02d", rep))
    for (sp in c("weak", "medium", "strong")) {
      legacy <- file.path(rep_dir, sp)
      if (dir.exists(legacy)) {
        unlink(legacy, recursive = TRUE)
        log_info("Removed legacy scenario subdirectory: ", legacy)
      }
    }
    log_info("Dataset2 replicate ", rep, "/", n_rep, " (seed ", rep_seed, ")")
    sym <- sym_discrete_baseline(
      ncells_total = n_cells,
      ngenes = ngenes,
      randseed = rep_seed,
      min_popsize = cfg$sym_min_popsize,
      Sigma = cfg$sym_sigma %||% 0.22,
      nevf = as.integer(cfg$sym_nevf %||% 14L),
      n_de_evf = as.integer(cfg$sym_n_de_evf %||% 11L),
      gene_effect_prob = cfg$sym_gene_effect_prob %||% 0.38,
      vary = cfg$sym_vary %||% "s",
      geffect_mean = cfg$sym_geffect_mean %||% 0,
      gene_effects_sd = cfg$sym_gene_effects_sd %||% 1,
      scale_s = cfg$sym_scale_s %||% 1
    )
    population <- sym$population
    counts_gc <- sym$counts
    cell_meta_sym <- sym[["cell_meta"]]

    assign <- assign_condition_and_global_batch(
      population = population,
      n_batches = n_batches,
      cells_per_batch = cells_per_batch,
      seed = rep_seed + 5L
    )
    condition <- assign$condition
    batch <- assign$batch

    gene_df <- gene_partition_table(
      ngenes,
      seed = rep_seed + 9L,
      n_pcs = cfg$n_pcs,
      effect_magnitude = 1
    )
    gene_df$het_type <- ifelse(
      gene_df$affected == "affected",
      "homogeneous",
      "unaffected"
    )
    gene_df <- assign_gene_effect_tiers(gene_df, tier_shifts, seed = rep_seed + 13L)
    gene_df$effect_size <- gene_df$effect_shift

    log_mu0 <- t(log(counts_gc + 1)) # cells x genes
    n_pcs <- min(cfg$n_pcs, n_cells - 1L, ngenes)
    pr <- stats::prcomp(log_mu0, center = TRUE, scale. = FALSE, rank. = n_pcs)
    U <- pr$x
    H <- minmax_cols(U)

    pert_rows <- which(condition == "perturbed")
    tau <- matrix(0, nrow = n_cells, ncol = ngenes)
    if (length(pert_rows) > 0L) {
      tau[pert_rows, ] <- matrix(
        rep(gene_df$effect_shift, each = length(pert_rows)),
        nrow = length(pert_rows),
        ncol = ngenes
      )
    }
    log_mu1 <- log_mu0 + tau

    use_sym_obs <- identical(sym$source, "sym_sim") &&
      !is.null(cell_meta_sym) &&
      isTRUE(cfg$sym_use_observed_pipeline %||% TRUE)

    if (use_sym_obs) {
      log_info(
        "Dataset2: SymSim True2ObservedCounts (technical) then DivideBatches-style batch, then condition on log scale."
      )
      obs_tech <- sym_true_to_observed_counts(
        true_gxc = counts_gc,
        cell_meta = cell_meta_sym,
        cfg = cfg,
        seed = rep_seed + 50L
      )
      if (is.null(obs_tech)) {
        log_stop("True2ObservedCounts returned NULL (SymSim missing or failed).")
      }
      beff <- cfg$sym_batch_effect_size %||% 1
      obs_batch <- sym_apply_batch_structured(
        observed_gxc = obs_tech,
        batch_index = batch,
        batch_effect_size = beff,
        seed = rep_seed + 77L
      )
      log_tech <- t(log(pmax(obs_tech, 0L) + 1L))
      log_bt <- t(log(pmax(obs_batch, 0L) + 1L))
      log_batchfree <- log_tech
      if (length(pert_rows) > 0L) {
        log_batchfree[pert_rows, ] <- log_batchfree[pert_rows, ] + tau[pert_rows, , drop = FALSE]
      }
      log_mu_obs <- log_bt
      if (length(pert_rows) > 0L) {
        log_mu_obs[pert_rows, ] <- log_mu_obs[pert_rows, ] + tau[pert_rows, , drop = FALSE]
      }
      beta <- log_bt - log_tech
      batch_linear <- matrix(0, nrow = n_cells, ncol = ngenes)
    } else {
      log_info("Dataset2: fallback path (true log counts + optional manual batch_log_sd).")
      log_batchfree <- log_mu0
      log_batchfree[pert_rows, ] <- log_mu1[pert_rows, ]
      blsd <- suppressWarnings(as.numeric(cfg$batch_log_sd %||% 0))
      if (length(blsd) != 1L || is.na(blsd) || blsd <= 0) {
        batch_linear <- matrix(0, nrow = n_cells, ncol = ngenes)
      } else {
        set.seed(rep_seed + 121L)
        batch_shift <- matrix(
          stats::rnorm(ngenes * n_batches, sd = blsd),
          nrow = ngenes,
          ncol = n_batches
        )
        batch_linear <- matrix(0, nrow = n_cells, ncol = ngenes)
        bi <- batch
        for (g in seq_len(ngenes)) {
          batch_linear[, g] <- batch_shift[g, bi]
        }
      }
      log_mu_obs <- log_batchfree + batch_linear
      beta <- batch_linear
    }

    set.seed(rep_seed + 202L)
    th_lo <- cfg$nb_theta_min %||% 12
    th_hi <- cfg$nb_theta_max %||% 45
    theta_g <- stats::runif(ngenes, min = th_lo, max = th_hi)
    mu_obs <- exp(log_mu_obs)
    Y <- nb_matrix(mu_obs, theta_g, seed = rep_seed + 303L)

    obs <- data.frame(
      cell_id = sprintf("cell_%05d", seq_len(n_cells)),
      condition = condition,
      batch = sprintf("batch_%02d", batch),
      batch_index = batch,
      cell_type = sprintf("type_%d", population),
      replicate_id = rep,
      sym_source = sym$source,
      stringsAsFactors = FALSE
    )

    var <- data.frame(
      gene_id = gene_df$gene_id,
      affected = gene_df$affected,
      heterogeneity = gene_df$het_type,
      direction = gene_df$direction,
      effect_tier = gene_df$effect_tier,
      effect_shift = gene_df$effect_shift,
      effect_size = gene_df$effect_size,
      assigned_pc = gene_df$assigned_pc,
      stringsAsFactors = FALSE
    )

    truth <- assemble_truth_list(
      log_mu0 = log_mu0,
      log_mu1 = log_mu1,
      log_mu_batchfree = log_batchfree,
      log_mu_obs = log_mu_obs,
      tau = tau,
      beta = beta,
      pc_scores = U,
      pc_scores_normalized = H
    )

    summary_list <- list(
      dataset = cfg$dataset,
      replicate = rep,
      design = "sym_true_then_true2observed_then_structured_batch_then_condition",
      effect_tiers = tier_shifts,
      sym_source = sym$source,
      sym_seed = sym$sym_seed,
      sym_use_observed_pipeline = use_sym_obs,
      sym_protocol = cfg$sym_protocol %||% "nonUMI",
      sym_batch_effect_size = cfg$sym_batch_effect_size %||% 1,
      master_seed = cfg$master_seed,
      replicate_seed = rep_seed,
      ngenes = ngenes,
      ncells = n_cells,
      cells_per_batch = cells_per_batch,
      n_batches = n_batches,
      batch_log_sd = suppressWarnings(as.numeric(cfg$batch_log_sd %||% 0)),
      theta_range = c(th_lo, th_hi)
    )

    out_dir <- file.path(data_root, sprintf("replicate_%02d", rep))
    bundle <- write_sim_bundle(
      out_dir = out_dir,
      counts_cxg = Y,
      obs = obs,
      var = var,
      truth = truth,
      summary_list = summary_list,
      seeds = list(
        master = cfg$master_seed,
        replicate = rep_seed,
        sym = sym$sym_seed
      )
    )

    pc_out <- data.frame(cell_id = obs$cell_id, U, check.names = FALSE)
    utils::write.csv(pc_out, file.path(out_dir, "pc_scores.csv"), row.names = FALSE)
    H_out <- data.frame(cell_id = obs$cell_id, H, check.names = FALSE)
    utils::write.csv(H_out, file.path(out_dir, "pc_scores_normalized.csv"), row.names = FALSE)

    fig_dir <- file.path(out_dir, "figures")
    ensure_dir(fig_dir)
    n_hvg_umap <- as.integer(cfg$umap_pca_n_hvg %||% min(1800L, ngenes))
    umap_lat_pick <- cfg$umap_gene_select_latent %||% cfg$umap_gene_select %||% "f_stat"
    umap_bf_pick <- cfg$umap_gene_select_batch_free %||% cfg$umap_gene_select %||% "joint_tc"
    umap_obs_pick <- cfg$umap_gene_select_observed %||% cfg$umap_gene_select %||% "batch_within_condition"
    umap_md <- cfg$umap_min_dist %||% 0.12
    log0_h <- build_umap_expr_input(
      log_mu0, population, n_hvg_umap, rep_seed + 400L, umap_lat_pick,
      condition = condition, batch_index = batch
    )
    logbf_h <- build_umap_expr_input(
      log_batchfree, population, n_hvg_umap, rep_seed + 401L, umap_bf_pick,
      condition = condition, batch_index = batch
    )
    logy_h <- build_umap_expr_input(
      log(Y + 1), population, n_hvg_umap, rep_seed + 402L, umap_obs_pick,
      condition = condition, batch_index = batch
    )
    latent_scores <- pc_for_umap(log0_h, max_rank = min(30L, n_pcs), seed = rep_seed + 401L)
    emb_latent <- umap_from_scores(latent_scores, seed = rep_seed + 501L, min_dist = umap_md)
    emb_bf <- umap_from_scores(
      pc_for_umap(logbf_h, max_rank = min(30L, n_pcs), seed = rep_seed + 402L),
      seed = rep_seed + 502L,
      min_dist = umap_md
    )
    emb_obs <- umap_from_scores(
      pc_for_umap(logy_h, max_rank = min(30L, n_pcs), seed = rep_seed + 403L),
      seed = rep_seed + 503L,
      min_dist = umap_md
    )
    save_umap_coordinates_csv(
      embeddings = list(latent = emb_latent, batch_free = emb_bf, observed = emb_obs),
      obs = obs,
      fig_dir = fig_dir
    )
    log_info("UMAP coordinates for scanpy saved under: ", fig_dir)

    append_manifest(
      manifest_path,
      data.frame(
        dataset = "dataset2",
        replicate = rep,
        scenario = NA_character_,
        out_dir = bundle$out_dir,
        stringsAsFactors = FALSE
      )
    )
    maybe_postprocess_bundle(bundle$out_dir, code_dir)
  }
  log_info("Dataset2 simulation complete.")
}

if (sys.nframe() == 0 && !interactive()) {
  tryCatch(
    main(),
    error = function(e) {
      message(conditionMessage(e))
      quit(save = "no", status = 1)
    }
  )
}
