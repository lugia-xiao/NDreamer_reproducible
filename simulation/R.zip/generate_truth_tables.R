# Optional helpers for assembling dense truth structures.
# Main assembly lives in simulate_dataset*.R for readability.

assemble_truth_list <- function(log_mu0,
                                log_mu1,
                                log_mu_batchfree,
                                log_mu_obs,
                                tau,
                                beta,
                                pc_scores,
                                pc_scores_normalized) {
  list(
    log_mu0 = log_mu0,
    log_mu1 = log_mu1,
    log_mu_batchfree = log_mu_batchfree,
    log_mu_obs = log_mu_obs,
    mu0 = expm1(log_mu0),
    mu1 = expm1(log_mu1),
    mu_obs_batchfree = expm1(log_mu_batchfree),
    mu_obs = expm1(log_mu_obs),
    tau = tau,
    beta = beta,
    pc_scores = pc_scores,
    pc_scores_normalized = pc_scores_normalized
  )
}
