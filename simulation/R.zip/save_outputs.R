# Save matrices + metadata + manifest entries for Python conversion.

write_sim_bundle <- function(out_dir,
                             counts_cxg,
                             obs,
                             var,
                             truth,
                             summary_list,
                             seeds) {
  ensure_dir(out_dir)
  if (!requireNamespace("Matrix", quietly = TRUE)) {
    log_stop("Matrix package required for MTX export.")
  }
  counts_gxc <- Matrix::t(Matrix::Matrix(counts_cxg, sparse = TRUE))
  mtx_plain <- file.path(out_dir, "counts.mtx")
  Matrix::writeMM(counts_gxc, file = mtx_plain)
  gzip_bin <- Sys.which("gzip")
  if (gzip_bin == "") {
    log_stop("gzip executable not found; cannot compress counts.mtx")
  }
  status <- system2(gzip_bin, c("-nf", mtx_plain))
  if (!identical(as.integer(status), 0L)) {
    log_stop("gzip failed with status ", status)
  }
  mtx_gz <- paste0(mtx_plain, ".gz")
  utils::write.csv(obs, file.path(out_dir, "obs.csv"), row.names = FALSE)
  utils::write.csv(var, file.path(out_dir, "var.csv"), row.names = FALSE)
  saveRDS(truth, file.path(out_dir, "truth.rds"), compress = "xz")
  saveRDS(seeds, file.path(out_dir, "seeds.rds"))
  yaml::write_yaml(summary_list, file.path(out_dir, "simulation_summary.yaml"))
  list(
    out_dir = normalizePath(out_dir),
    obs_csv = normalizePath(file.path(out_dir, "obs.csv")),
    var_csv = normalizePath(file.path(out_dir, "var.csv")),
    mtx_gz = normalizePath(mtx_gz)
  )
}

manifest_bundle_exists <- function(out_dir) {
  file.exists(file.path(out_dir, "counts.mtx.gz")) ||
    file.exists(file.path(out_dir, "counts.mtx"))
}

prune_manifest_rows <- function(df) {
  if (nrow(df) == 0L) {
    return(df)
  }
  keep <- vapply(seq_len(nrow(df)), function(i) {
    od <- as.character(df$out_dir[i])
    nzchar(od) && manifest_bundle_exists(od)
  }, logical(1))
  df[keep, , drop = FALSE]
}

append_manifest <- function(manifest_path, entry_df) {
  ensure_dir(dirname(manifest_path))
  if (file.exists(manifest_path)) {
    prev <- utils::read.csv(manifest_path, stringsAsFactors = FALSE)
    prev <- prune_manifest_rows(prev)
    key <- entry_df$out_dir[[1]]
    prev <- prev[prev$out_dir != key, , drop = FALSE]
    out <- rbind(prev, entry_df)
  } else {
    out <- entry_df
  }
  utils::write.csv(prune_manifest_rows(out), manifest_path, row.names = FALSE)
}

# After each replicate: build adata.h5ad + Scanpy UMAPs so figures exist without run_all.R.
maybe_postprocess_bundle <- function(out_dir, code_dir) {
  py <- Sys.which("python")
  if (identical(Sys.getenv("SIM_SKIP_POSTPROCESS", unset = ""), "1") || !nzchar(py)) {
    return(invisible())
  }
  root <- normalizePath(file.path(code_dir, "..", ".."))
  gd <- normalizePath(file.path(root, "generate_simulation_dataset"))
  conv <- file.path(gd, "python", "convert_to_h5ad.py")
  plt <- file.path(gd, "python", "plot_umaps_scanpy.py")
  od <- normalizePath(out_dir)
  st <- system2(py, c(conv, "--out-dir", od, "--overwrite"), stdout = FALSE, stderr = FALSE)
  if (!identical(as.integer(st), 0L)) {
    log_info("convert_to_h5ad failed for ", od, " (exit ", st, ")")
    return(invisible())
  }
  st2 <- system2(py, c(plt, "--out-dir", od), stdout = FALSE, stderr = FALSE)
  if (!identical(as.integer(st2), 0L)) {
    log_info("plot_umaps_scanpy failed for ", od, " (exit ", st2, ")")
  }
  invisible()
}
