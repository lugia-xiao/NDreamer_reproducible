# SymSim-backed baseline generation with a documented fallback.

sym_discrete_baseline <- function(ncells_total,
                                  ngenes,
                                  randseed,
                                  min_popsize,
                                  Sigma = 0.38,
                                  nevf = 10L,
                                  n_de_evf = 9L,
                                  gene_effect_prob = 0.25,
                                  vary = "s",
                                  geffect_mean = 0,
                                  gene_effects_sd = 1,
                                  scale_s = 1) {
  if (!requireNamespace("SymSim", quietly = TRUE)) {
    return(fallback_baseline(ncells_total, ngenes, randseed))
  }
  tryCatch(
    {
      suppressPackageStartupMessages(library(SymSim))
      res <- SymSim::SimulateTrueCounts(
        ncells_total = ncells_total,
        min_popsize = min_popsize,
        i_minpop = 1L,
        ngenes = ngenes,
        nevf = nevf,
        evf_type = "discrete",
        n_de_evf = n_de_evf,
        vary = vary,
        Sigma = Sigma,
        phyla = SymSim::Phyla5(),
        randseed = randseed,
        geffect_mean = geffect_mean,
        gene_effects_sd = gene_effects_sd,
        gene_effect_prob = gene_effect_prob,
        bimod = 0,
        scale_s = scale_s
      )
      counts <- res$counts # genes x cells
      if (nrow(counts) != ngenes || ncol(counts) != ncells_total) {
        stop("Unexpected SymSim count dimensions")
      }
      pop <- as.integer(as.character(res$cell_meta$pop))
      list(
        counts = counts,
        population = pop,
        source = "sym_sim",
        sym_seed = randseed,
        cell_meta = res$cell_meta
      )
    },
    error = function(e) {
      warning("SymSim failed (", conditionMessage(e), "); using fallback simulator.")
      fallback_baseline(ncells_total, ngenes, randseed)
    }
  )
}

# Lightweight fallback: gamma-Poisson layers with discrete cell types.
fallback_baseline <- function(ncells_total, ngenes, randseed) {
  set.seed(randseed)
  pop <- sample.int(5L, ncells_total, replace = TRUE)
  cell_scale <- rgamma(ncells_total, shape = 8, rate = 8)
  gene_base <- rgamma(ngenes, shape = 2, rate = 2)
  rate <- outer(gene_base, cell_scale, "*")
  type_log_mult <- c(-1.05, -0.48, 0, 0.48, 1.05)
  cell_type_amp <- exp(type_log_mult[pop])
  rate <- rate * matrix(
    rep(cell_type_amp, each = ngenes),
    nrow = ngenes,
    ncol = ncells_total
  )
  noise <- matrix(rnorm(ngenes * ncells_total, sd = 0.11), nrow = ngenes)
  rate <- pmax(rate * exp(noise), 1e-8)
  counts <- matrix(
    stats::rpois(ngenes * ncells_total, as.vector(rate)),
    nrow = ngenes,
    ncol = ncells_total
  )
  list(
    counts = counts,
    population = pop,
    source = "fallback_gamma_poisson",
    sym_seed = randseed,
    cell_meta = NULL
  )
}

# SymSim technical layer: true transcript counts -> observed read counts (genes x cells).
sym_true_to_observed_counts <- function(true_gxc, cell_meta, cfg, seed) {
  if (!requireNamespace("SymSim", quietly = TRUE)) {
    return(NULL)
  }
  set.seed(seed)
  ngenes <- nrow(true_gxc)
  utils::data("gene_len_pool", package = "SymSim", envir = environment())
  gene_len <- sample(gene_len_pool, ngenes, replace = FALSE)
  suppressPackageStartupMessages(library(SymSim))
  ab_lim <- cfg$sym_amp_bias_limit %||% c(-0.2, 0.2)
  if (length(ab_lim) == 1L) {
    ab_lim <- rep(ab_lim, 2L)
  }
  res <- SymSim::True2ObservedCounts(
    true_counts = true_gxc,
    meta_cell = cell_meta,
    protocol = cfg$sym_protocol %||% "nonUMI",
    alpha_mean = cfg$sym_alpha_mean %||% 0.1,
    alpha_sd = cfg$sym_alpha_sd %||% 0.05,
    gene_len = gene_len,
    depth_mean = cfg$sym_depth_mean %||% 1e5,
    depth_sd = cfg$sym_depth_sd %||% 3e3,
    lenslope = cfg$sym_lenslope %||% 0.02,
    nbins = as.integer(cfg$sym_nbins %||% 20L),
    amp_bias_limit = ab_lim,
    rate_2PCR = cfg$sym_rate_2PCR %||% 0.8,
    nPCR1 = as.integer(cfg$sym_nPCR1 %||% 16L),
    nPCR2 = as.integer(cfg$sym_nPCR2 %||% 10L),
    LinearAmp = isTRUE(cfg$sym_linear_amp %||% FALSE),
    LinearAmp_coef = cfg$sym_linear_amp_coef %||% 2000
  )
  res[[1L]]
}

# SymSim DivideBatches-style multiplicative batch on log2 counts, using caller-supplied batch ids.
sym_apply_batch_structured <- function(observed_gxc, batch_index, batch_effect_size, seed) {
  set.seed(seed)
  obs <- as.matrix(observed_gxc)
  ngenes <- nrow(obs)
  ncells <- ncol(obs)
  bi <- as.integer(batch_index)
  nbatch <- max(bi)
  gene_mean <- stats::rnorm(ngenes, 0, 1)
  mean_matrix <- matrix(0, nrow = ngenes, ncol = nbatch)
  for (igene in seq_len(ngenes)) {
    mean_matrix[igene, ] <- stats::runif(
      nbatch,
      min = gene_mean[igene] - batch_effect_size,
      max = gene_mean[igene] + batch_effect_size
    )
  }
  idx_i <- rep(seq_len(ngenes), times = ncells)
  idx_b <- rep(bi, each = ngenes)
  mu_cell <- mean_matrix[cbind(idx_i, idx_b)]
  bf <- matrix(
    stats::rnorm(ngenes * ncells, mean = mu_cell, sd = 0.01),
    nrow = ngenes,
    ncol = ncells
  )
  lv <- log2(pmax(obs, 1e-12))
  out <- round(2^(lv + bf))
  pmax(out, 0L)
}
