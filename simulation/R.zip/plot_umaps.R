# UMAP coordinates (R): PCA + uwot embedding, saved as CSV for Scanpy plotting in Python.

pc_for_umap <- function(expr_cxg, max_rank, seed) {
  max_rank <- min(max_rank, nrow(expr_cxg) - 1L, ncol(expr_cxg))
  if (max_rank < 2L) {
    max_rank <- 2L
  }
  pr <- stats::prcomp(expr_cxg, center = TRUE, scale. = TRUE, rank. = max_rank)
  pr$x
}

umap_from_scores <- function(scores, seed, min_dist = 0.12) {
  if (!requireNamespace("uwot", quietly = TRUE)) {
    log_stop("uwot is required for UMAP coordinates.")
  }
  scores <- as.matrix(scores)
  if (ncol(scores) < 2L) {
    stop("Need at least two dimensions for UMAP.")
  }
  uwot::umap(
    scores,
    n_neighbors = min(30L, nrow(scores) - 1L),
    min_dist = min_dist,
    spread = 1,
    metric = "cosine",
    n_threads = 1,
    verbose = FALSE,
    ret_model = FALSE,
    seed = seed
  )
}

# Write 2D UMAP coordinates for each embedding; Python (scanpy) renders readable figures.
save_umap_coordinates_csv <- function(embeddings, obs, fig_dir) {
  ensure_dir(fig_dir)
  old_png <- list.files(fig_dir, pattern = "^umap_.*\\.png$", full.names = TRUE)
  if (length(old_png) > 0L) {
    unlink(old_png)
  }
  name_map <- c(
    latent = "umap_coords_latent.csv",
    batch_free = "umap_coords_batch_free.csv",
    observed = "umap_coords_observed.csv"
  )
  for (nm in names(embeddings)) {
    emb <- embeddings[[nm]]
    stopifnot(nrow(emb) == nrow(obs))
    fn <- name_map[[nm]]
    if (is.null(fn)) {
      log_stop("Unknown embedding name: ", nm)
    }
    df <- data.frame(
      cell_id = obs$cell_id,
      UMAP1 = emb[, 1L],
      UMAP2 = emb[, 2L],
      stringsAsFactors = FALSE
    )
    utils::write.csv(df, file.path(fig_dir, fn), row.names = FALSE)
  }
  invisible(fig_dir)
}
